VERSION = (3, 0, 3)

__version__ = '.'.join(map(str, VERSION))

version = lambda: __version__
