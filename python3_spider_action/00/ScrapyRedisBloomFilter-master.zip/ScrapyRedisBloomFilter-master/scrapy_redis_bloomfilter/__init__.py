# -*- coding: utf-8 -*-
from .connection import (  # NOQA
    get_redis,
    get_redis_from_settings,
)


__author__ = 'Germey'
__email__ = 'cqc@cuiqingcai.com'
__version__ = '0.7.0'
