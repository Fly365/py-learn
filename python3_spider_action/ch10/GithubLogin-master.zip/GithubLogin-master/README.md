# Github Login

Login Github with Requests

## 2020/2/10 更新

失效问题可见：https://github.com/Python3WebSpider/GithubLogin/issues/1
